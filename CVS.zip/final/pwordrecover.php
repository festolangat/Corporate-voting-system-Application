<form action="recover.php" method="POST">
<span style="color: #000000;">Username</span><br>
<input type="text" name="username" value="" /><br><br>
<input type="submit" value="Next" />
</form>