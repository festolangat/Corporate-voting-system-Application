<?php
	//Start session
	session_start();
	
	//Unset the variables stored in session
	unset($_SESSION['SESS_MEMBER_ID']);
	//unset($_SESSION['SESS_COURSE']);
	unset($_SESSION['NAME']);
?>
<!DOCTYPE HTML>
<html lang="en-US">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="refresh" content="10;url=index.php">
        <title>Logout</title>
    </head>
	

    <body style="font-family: arial; font-size: 20px; background:url(images/templatemo-slide-1.jpg); width: 400px; height:auto; float:left; margin-top:50px; color:white;">
		 
			Please Wait ...<img src="images/loading.gif"><br /><br />Your Vote has been counted!.Remember you cannot vote again! Thank you for participating.<br />
        <i><a href='index.php' style="color:white; text-decoration:none;">Home page</a></i>
    </body>
</html>
<?php
	
	session_destroy();
?>