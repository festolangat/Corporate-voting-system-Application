<?php
	//Start session
	session_start();
	
	//Unset the variables stored in session
	unset($_SESSION['SESS_MEMBER_ID']);
	//unset($_SESSION['SESS_COURSE']);
	unset($_SESSION['NAME']);
?>
<!DOCTYPE HTML>
<html lang="en-US">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="refresh" content="10;url=cpanel.php">
        <title>Logout successful</title>
    </head>
	

    <body style="font-family: arial; font-size: 20px; background:url(images/templatemo-slide-1.jpg); width: 250px; height:auto; float:left; margin-top:50px; color:white;">
		Wait ...<img src="images/loading.gif">
	
        <!-- Note: don't tell people to `click` the link, just tell them that it is a link. -->
        
    </body>
</html>
<?php
	
	session_destroy();
?>