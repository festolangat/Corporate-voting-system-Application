<form action="saveidnum.php" method="POST">
ID Number<br>
<input type="text" name="idnapa" value="" required="required" /><br>
Firstname<br>
<input type="text" name="fname" value="" required="required" /><br>
Lastname<br>
<input type="text" name="lname" value="" required="required" /><br>
Profession<br>
<select name="profession">
	<?php
	include('../connect.php');
	$result = $db->prepare("SELECT * FROM profession");
		$result->bindParam(':userid', $res);
		$result->execute();
		for($i=0; $row = $result->fetch(); $i++){
	?>
		<option><?php echo $row['name']; ?></option>
	<?php
	}
	?>
</select><br>
<input type="submit" value="Save" />
</form>