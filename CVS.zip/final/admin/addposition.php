<form action="saveposition.php" method="POST">
Position<br>
<input type="text" name="position" value="" /><br>
<input type="submit" value="Save" />
</form>