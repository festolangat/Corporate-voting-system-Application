<form action="backup/import.php" method="POST" enctype="multipart/form-data">
<input type="file" name="image" class="ed"><br />
<input type="submit" value="Save" />
</form>