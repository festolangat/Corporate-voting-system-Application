DROP TABLE about;

CREATE TABLE `about` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO about VALUES("1","1.So what is CVS?","Corporate voting system (OVS) will reduce the time to travel to polling station, time spent in long queue. It will enable voters to vote anywhere, anytime since the application will be available on the web. Case of incorrect tallying of votes will be solv");



DROP TABLE admin;

CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO admin VALUES("1","class","class");



DROP TABLE candidates;

CREATE TABLE `candidates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `position` varchar(100) NOT NULL,
  `votes` int(11) NOT NULL,
  `image` varchar(100) NOT NULL,
  `profession` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;

INSERT INTO candidates VALUES("33","Kenneth Koech","Secretart_general","1","207338_10151525601618336_901253985_n.jpg","BCOM");
INSERT INTO candidates VALUES("34","Wcyliffe Otieno","Board_Chairman","1","images_1_.jpg","MMPE");
INSERT INTO candidates VALUES("35","Martix Yala","Board_Chairman","3","GOD.jpg","BIT");
INSERT INTO candidates VALUES("37","James Nganga","Secretart_general","2","wire_transfer_256.png","BPS");
INSERT INTO candidates VALUES("38","Menza Odabil","President","2","dup^neva say dieas^.gif","MMPE");
INSERT INTO candidates VALUES("39","Kericho Bett","President","0","1387991012895.jpg","BCOM");



DROP TABLE faq;

CREATE TABLE `faq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(1000) NOT NULL,
  `content` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO faq VALUES("6","1.How do i vote?","1.Create users account by click on register button<br />2.Login to vote by entering username and password you create in step 1.<br />3.Proceed to vote panel.<br />5.Before submitting the choice ,you will have to confirm the choice, if it is correct press ");
INSERT INTO faq VALUES("7","2.Who should vote?","Every shareholder of the company is entitle vote. As long as one has unique authorized number.");



DROP TABLE list_stu_num;

CREATE TABLE `list_stu_num` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_number` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `course` varchar(100) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO list_stu_num VALUES("6","123-qwe","notuse","Odabil, Menza Pastor","BPS","2016-02-06 18:22:31");
INSERT INTO list_stu_num VALUES("7","12345-mn","used","Kenya, Nation Skillfull","BCOM","2016-02-06 20:15:36");
INSERT INTO list_stu_num VALUES("8","45-com","used","Langat, Festus Boss","BPS","2016-02-06 21:14:37");
INSERT INTO list_stu_num VALUES("9","234-langat","used","Langat, Gilbert kiop","BPS","2016-02-10 08:58:46");
INSERT INTO list_stu_num VALUES("10","90","used","Juma, Jacob ","MMPE","2016-05-19 16:39:00");



DROP TABLE position;

CREATE TABLE `position` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO position VALUES("1","President");
INSERT INTO position VALUES("6","Board_Chairman");
INSERT INTO position VALUES("7","Secretart_general");



DROP TABLE profession;

CREATE TABLE `profession` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO profession VALUES("2","Business man");
INSERT INTO profession VALUES("3","Technician");
INSERT INTO profession VALUES("4","Manager");
INSERT INTO profession VALUES("5","Chancellor");



DROP TABLE votedetails;

CREATE TABLE `votedetails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `candidate` varchar(100) NOT NULL,
  `voters` varchar(100) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO votedetails VALUES("2","Kenneth Koech","12345-mn","2016-02-06 20:16:57");
INSERT INTO votedetails VALUES("3","Martix Yala","12345-mn","2016-02-06 20:16:57");
INSERT INTO votedetails VALUES("4","Menza Odabil","45-com","2016-02-06 21:17:10");
INSERT INTO votedetails VALUES("5","James Nganga","45-com","2016-02-06 21:17:10");
INSERT INTO votedetails VALUES("6","Wcyliffe Otieno","45-com","2016-02-06 21:17:10");
INSERT INTO votedetails VALUES("7","Menza Odabil","234-langat","2016-02-10 09:00:31");
INSERT INTO votedetails VALUES("8","0","234-langat","2016-02-10 09:00:31");
INSERT INTO votedetails VALUES("9","Martix Yala","234-langat","2016-02-10 09:00:31");



DROP TABLE voters;

CREATE TABLE `voters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `profession` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `question` varchar(200) NOT NULL,
  `answer` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO voters VALUES("7","Ntimama, Natalie  Usiku","BSIT","990-Ntimama","ntimama","notvoted","what is your favorite pet","sportpesa");
INSERT INTO voters VALUES("8","Odabil, Menza Pastor","BPS","123-qwe","menza","notvoted","what is your favorite movie","James bond");
INSERT INTO voters VALUES("9","Kenya, Nation Skillfull","BCOM","12345-mn","12345-mn","voted","what is your favorite color","green");
INSERT INTO voters VALUES("10","Langat, Festus Boss","BPS","45-com","festo","voted","what is your favorite pet","Justbet");
INSERT INTO voters VALUES("11","Langat, Gilbert kiop","BPS","234-langat","12341","voted","what is your favorite movie","jamesbound");
INSERT INTO voters VALUES("12","Juma, Jacob ","MMPE","90","90","notvoted","what is your favorite color","blue");



