<form action="savecourse.php" method="POST">
Profession<br>
<input type="text" name="course" value="" /><br>
<input type="submit" value="Save" />
</form>