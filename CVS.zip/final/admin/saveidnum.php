<?php
session_start();
include('../connect.php');
function createRandomPassword() {
	$chars = "003232303232023232023456789";
	srand((double)microtime()*1000000);
	$i = 0;
	$pass = '' ;
	while ($i <= 8) {
		$num = rand() % 33;
		$tmp = substr($chars, $num, 1);
		$pass = $pass . $tmp;
		$i++;
	}
	return $pass;
}

$a = 'VL'.createRandomPassword().'Rf';
$b = 'notuse';
$c = $_POST['profession'];
$f = $_POST['idnapa'];
$d = $_POST['lname'].', '.$_POST['fname'];

// query
$sql = "INSERT INTO list_stu_num (id_number,idnapa,status,name,profession) VALUES (:a,:f,:b,:c,:d)";
$q = $db->prepare($sql);
$q->execute(array(':a'=>$a,':f'=>$f,':b'=>$b,':c'=>$d,':d'=>$c));
header("location: idnumbers.php?#reference#code:$a");


?>