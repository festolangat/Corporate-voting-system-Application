<?php
	include('../connect.php');
	$id=$_GET['id'];
	$results = $db->prepare("SELECT * FROM about WHERE id= :userid");
	$results->bindParam(':userid', $id);
	$results->execute();
	for($i=0; $rows = $results->fetch(); $i++){
?>
<form action="saveeditabout.php" method="POST">
<input type="hidden" name="memids" value="<?php echo $id; ?>" />
Title<br>
<input type="text" name="name" value="<?php echo $rows['title']; ?>" /><br>
Content<br>
<input type="text" name="description" value="<?php echo $rows['content']; ?>" /><br>
<input type="submit" value="Update" />
</form>
<?php
}
?>