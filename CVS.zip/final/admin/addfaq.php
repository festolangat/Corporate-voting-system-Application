<form action="savefaq.php" method="POST">
Title<br>
<input type="text" name="name" value="" /><br>
Content<br>
<input type="text" name="description" value="" /><br>
<input type="submit" value="Save" />
</form>