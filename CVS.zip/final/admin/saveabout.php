<?php
session_start();
include('../connect.php');
$a = $_POST['name'];
$b = $_POST['description'];
// query
$sql = "INSERT INTO about (title,content) VALUES (:a,:b)";
$q = $db->prepare($sql);
$q->execute(array(':a'=>$a,':b'=>$b));
header("location: about.php");


?>