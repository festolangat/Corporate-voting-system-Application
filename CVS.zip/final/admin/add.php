<?php
session_start();
include('../connect.php');

// new data
$file=$_FILES['image']['tmp_name'];
	$image= addslashes(file_get_contents($_FILES['image']['tmp_name']));
	$image_name= addslashes($_FILES['image']['name']);
	$image_size= getimagesize($_FILES['image']['tmp_name']);
		if ($image_size==FALSE) {
		
			echo "That's not an image!";
			
		}else{
		move_uploaded_file($_FILES["image"]["tmp_name"],"candidates/" . $_FILES["image"]["name"]);
		$name = $_POST['name'];
		$position = $_POST['position'];
		$location=$_FILES["image"]["name"];		
		$e=$_POST['course'];
		$j=$_POST['idnapa'];
// query
$sql = "INSERT INTO candidates (idnapa,name,position,image,profession) VALUES (:j,:a,:b,:c,:e)";
$q = $db->prepare($sql);
$q->execute(array(':j'=>$j,':a'=>$name,':b'=>$position,':c'=>$location,':e'=>$e));
header("location: candidates.php?#id#'$j'");
}


?>