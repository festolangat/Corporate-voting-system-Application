<form action="saveadmin.php" method="POST">
Username<br>
<input type="text" name="username" value="" /><br>
Passowrd<br>
<input type="text" name="password" value="" /><br>
<input type="submit" value="Save" />
</form>