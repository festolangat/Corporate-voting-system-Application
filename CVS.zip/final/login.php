<img src="images/loading.gif">
<?php
	//Start session
	session_start();
	
	//Array to store validation errors
	$errmsg_arr = array();
	
	//Validation error flag
	$flagerror = false;
	
	//Connect to mysql server
	$link = mysql_connect('localhost','root',"");
	if(!$link) {
		die('Connection failed!' . mysql_error());
	}
	
	//Select database
	$db = mysql_select_db('onlinevoting', $link);
	if(!$db) {
		die("There is a problem with your database connection!". mysql_error());
	}
	
	//Function to sanitize values received from the form. Prevents SQL injection
	function clean($str) {
		$str = @trim($str);
		if(get_magic_quotes_gpc()) {
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}
	echo 
	//Sanitize the POST values
	$time = clean($_POST['date_time']);
	$login = clean($_POST['username']);
	$password = clean($_POST['password']);
	$position = clean($_POST['asas']);
	$stat='notvoted';	
	$level='1';
	//set voting closed time
	$check='18';
	//Check the time if the voting is closed.Default time for set is 18:00 hours
	$sum=$check-$time;
	if($sum>0)	
	{
	if($position=='voter') {
	$qry="SELECT * FROM voters WHERE  username='$login' AND password='$password' AND status='$stat'";
	}
	}
else{
	header("location:index.php?Voting is closed!");
	exit();
}
	//Querry to view results

	//Create query
	if($position=='Admin') {
	$qry="SELECT * FROM admin WHERE username='$login' AND password='$password' AND status='$level' ";
	}
	
	$result=mysql_query($qry);
	
	//Check whether the query was successful or not
	if($result) {
		if(mysql_num_rows($result) > 0) {
			//Login Successful
			if($position=='voter') {
			session_regenerate_id();
			$member = mysql_fetch_assoc($result);
			$_SESSION['SESS_MEMBER_ID'] = $member['username'];			
			$_SESSION['NAME'] = $member['name'];
			session_write_close();
			header("location: candidates_list.php?welcome='$login'");
			exit();
			}
			if($position=='Admin') {
			session_regenerate_id();
			$member = mysql_fetch_assoc($result);
			$_SESSION['SESS_MEMBER_ID'] = $member['username'];			
			$_SESSION['NAME'] = $member['name'];
			session_write_close();
			header("location: admin/index.php?#welcome$login ");
			exit();
			}
		}else {
			//Login failed
			
			header("location: index.php?#Wrong credential !Try again or Contact administrator for assistance");
			exit();
		}
	}else {
		//Wrong inputs
		header("location: index.php?#Sorry Invalid Inputs.Details doesn't exits ");
			exit();
	}
?>
