-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 04, 2016 at 04:34 PM
-- Server version: 5.5.32
-- PHP Version: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `onlinevoting`
--
CREATE DATABASE IF NOT EXISTS `onlinevoting` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `onlinevoting`;

-- --------------------------------------------------------

--
-- Table structure for table `about`
--

CREATE TABLE IF NOT EXISTS `about` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `about`
--

INSERT INTO `about` (`id`, `title`, `content`) VALUES
(1, '1.So what is CVS?', 'Corporate voting system (OVS) will reduce the time to travel to polling station, time spent in long queue. It will enable voters to vote anywhere, anytime since the application will be available on the web. Case of incorrect tallying of votes will be solv');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `status`) VALUES
(1, 'class', 'class', '1'),
(4, 'festo', 'festo', '0');

-- --------------------------------------------------------

--
-- Table structure for table `candidates`
--

CREATE TABLE IF NOT EXISTS `candidates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idnapa` int(8) NOT NULL,
  `name` varchar(100) NOT NULL,
  `position` varchar(100) NOT NULL,
  `votes` int(11) NOT NULL,
  `image` varchar(100) NOT NULL,
  `profession` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idnapa` (`idnapa`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=40 ;

--
-- Dumping data for table `candidates`
--

INSERT INTO `candidates` (`id`, `idnapa`, `name`, `position`, `votes`, `image`, `profession`) VALUES
(33, 123, 'Kenneth Koech', 'Secretart_general', 4, '207338_10151525601618336_901253985_n.jpg', 'Manager'),
(34, 234, 'Wcyliffe Otieno', 'Board_Chairman', 6, 'images_1_.jpg', 'Business man'),
(35, 897, 'Martix Yala', 'Board_Chairman', 6, 'GOD.jpg', 'Chancellor'),
(37, 567, 'James Nganga', 'Secretart_general', 6, 'wire_transfer_256.png', 'Technician'),
(38, 3478, 'Menza Odabil', 'President', 6, 'dup^neva say dieas^.gif', 'Farmer'),
(39, 2689, 'Kericho Bett', 'President', 4, '1387991012895.jpg', 'Lecturer');

-- --------------------------------------------------------

--
-- Table structure for table `faq`
--

CREATE TABLE IF NOT EXISTS `faq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(1000) NOT NULL,
  `content` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `faq`
--

INSERT INTO `faq` (`id`, `title`, `content`) VALUES
(6, '1.How do i vote?', '1.Create users account by click on register button<br />2.Login to vote by entering username and password you create in step 1.<br />3.Proceed to vote panel.<br />5.Before submitting the choice ,you will have to confirm the choice, if it is correct press '),
(7, '2.Who should vote?', 'Every shareholder of the company is entitle vote. As long as one has unique authorized number.');

-- --------------------------------------------------------

--
-- Table structure for table `list_stu_num`
--

CREATE TABLE IF NOT EXISTS `list_stu_num` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_number` varchar(100) NOT NULL,
  `idnapa` int(8) NOT NULL,
  `status` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `profession` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_number` (`id_number`),
  UNIQUE KEY `idnapa_2` (`idnapa`),
  KEY `idnapa` (`idnapa`),
  KEY `id_number_2` (`id_number`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `list_stu_num`
--

INSERT INTO `list_stu_num` (`id`, `id_number`, `idnapa`, `status`, `name`, `profession`, `date`) VALUES
(25, 'VL03232223Rf', 12345, 'used', 'sfsdf, fdsafsfsdsd', 'Business man', '0000-00-00 00:00:00'),
(27, 'VL523080Rf', 2147483647, 'notuse', 'Kirui, Mathew', 'Business man', '0000-00-00 00:00:00'),
(28, 'VL6322822Rf', 12343212, 'notuse', 'Mugare, Lewis', 'Manager', '0000-00-00 00:00:00'),
(29, 'VL482333302Rf', 12345678, 'used', 'Morti, M', 'Manager', '2016-08-04 14:25:53');

-- --------------------------------------------------------

--
-- Table structure for table `position`
--

CREATE TABLE IF NOT EXISTS `position` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `position`
--

INSERT INTO `position` (`id`, `name`) VALUES
(1, 'President'),
(6, 'Board_Chairman'),
(7, 'Secretart_general');

-- --------------------------------------------------------

--
-- Table structure for table `profession`
--

CREATE TABLE IF NOT EXISTS `profession` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `profession`
--

INSERT INTO `profession` (`id`, `name`) VALUES
(2, 'Business man'),
(3, 'Technician'),
(4, 'Manager'),
(5, 'Chancellor');

-- --------------------------------------------------------

--
-- Table structure for table `votedetails`
--

CREATE TABLE IF NOT EXISTS `votedetails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `candidate` varchar(100) NOT NULL,
  `voters` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=40 ;

--
-- Dumping data for table `votedetails`
--

INSERT INTO `votedetails` (`id`, `candidate`, `voters`, `date`) VALUES
(5, 'James Nganga', '45-com', '2016-02-07 05:17:10'),
(6, 'Wcyliffe Otieno', '45-com', '2016-02-07 05:17:10'),
(7, 'Menza Odabil', '234-langat', '2016-02-10 17:00:31'),
(8, '0', '234-langat', '2016-02-10 17:00:31'),
(9, 'Martix Yala', '234-langat', '2016-02-10 17:00:31'),
(13, 'Menza Odabil', '90', '2016-05-30 04:01:49'),
(14, '0', '90', '2016-05-30 04:01:49'),
(15, '0', '90', '2016-05-30 04:01:49'),
(16, 'Menza Odabil', '90', '2016-05-30 04:04:20'),
(17, 'Wcyliffe Otieno', '90', '2016-05-30 04:04:20'),
(18, 'James Nganga', '90', '2016-05-30 04:04:20'),
(19, 'Kericho Bett', 'V583023', '2016-06-16 16:43:37'),
(20, 'Wcyliffe Otieno', 'V583023', '2016-06-16 16:43:37'),
(21, 'Kenneth Koech', 'V583023', '2016-06-16 16:43:37'),
(22, 'Kericho Bett', 'V02262939', '2016-06-16 18:23:15'),
(23, 'Martix Yala', 'V02262939', '2016-06-16 18:23:15'),
(24, 'Kenneth Koech', 'V02262939', '2016-06-16 18:23:15'),
(25, 'Menza Odabil', 'V30702320', '2016-06-16 18:46:20'),
(26, 'Wcyliffe Otieno', 'V30702320', '2016-06-16 18:46:21'),
(27, 'Kenneth Koech', 'V30702320', '2016-06-16 18:46:21'),
(28, 'Kericho Bett', 'V02009042', '2016-06-16 19:35:57'),
(29, 'Wcyliffe Otieno', 'V02009042', '2016-06-16 19:35:57'),
(30, 'James Nganga', 'V02009042', '2016-06-16 19:35:57'),
(31, 'Mr kyangadnda', 'V333433332', '2016-06-16 19:39:54'),
(32, 'Wcyliffe Otieno', 'V333433332', '2016-06-16 19:39:54'),
(34, 'Kericho Bett', 'VL03232223Rf', '0000-00-00 00:00:00'),
(35, 'Martix Yala', 'VL03232223Rf', '0000-00-00 00:00:00'),
(36, 'James Nganga', 'VL03232223Rf', '0000-00-00 00:00:00'),
(37, 'Menza Odabil', 'VL482333302Rf', '2016-08-04 14:29:28'),
(38, 'Martix Yala', 'VL482333302Rf', '2016-08-04 14:29:28'),
(39, 'James Nganga', 'VL482333302Rf', '2016-08-04 14:29:28');

-- --------------------------------------------------------

--
-- Table structure for table `voters`
--

CREATE TABLE IF NOT EXISTS `voters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `profession` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `question` varchar(200) NOT NULL,
  `answer` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `voters`
--

INSERT INTO `voters` (`id`, `name`, `profession`, `username`, `password`, `status`, `question`, `answer`, `date`) VALUES
(13, 'K, Rolex Cheruiyot', 'Technician', 'V60030300', '123', 'notvoted', 'what is your favorite color', 'red', '0000-00-00 00:00:00'),
(14, 'G, Morine Gakii', 'Technician', 'V583023', '1234', 'voted', 'what is your favorite pet', 'betpawa', '0000-00-00 00:00:00'),
(15, 'M, Chirangu Kangethe', 'Business man', 'V00720232', '90', 'notvoted', 'what is your favorite color', 'kim', '0000-00-00 00:00:00'),
(16, 'Kiptoo, Kiptoo Kiptoo', 'Manager', 'V205200', '12345', 'notvoted', 'Select Security Question', 'dfgfd', '0000-00-00 00:00:00'),
(17, 'Cheruiyot, Rolex Cheru', 'Chancellor', 'V02262939', '1234', 'voted', 'what is your favorite movie', 'James bond', '0000-00-00 00:00:00'),
(18, 'Koskei, Cheruitot erick', 'Chancellor', 'V30702320', '1234', 'voted', 'what is your favorite color', 'red', '0000-00-00 00:00:00'),
(19, 'm, Mr Kyanganda K', 'Manager', 'V02009042', '1234', 'voted', 'what is your favorite color', 'red', '0000-00-00 00:00:00'),
(20, 'k, Festus Langat', 'Technician', 'V333433332', '123', 'voted', 'what is your favorite movie', 'james bond', '0000-00-00 00:00:00'),
(21, 'M, Gef Nyamea', 'Manager', 'V02032022', '123', 'notvoted', 'what is your favorite color', 'green', '0000-00-00 00:00:00'),
(22, 'sfsdf, fdsafsfsdsd', 'Business man', 'VL03232223Rf', '123', 'voted', 'what is your favorite color', 'blank', '0000-00-00 00:00:00'),
(23, 'Morti, M', 'Manager', 'VL482333302Rf', '1234', 'voted', 'what is your favorite movie', 'Harcules', '2016-08-04 14:28:35');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
