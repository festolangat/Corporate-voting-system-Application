<?php
	$query1=mysql_connect("localhost","root","");
	mysql_select_db("onlinevoting",$query1);

	$faq=mysql_query("select * from faq");
	//print 10 items
	echo '<div style="font-size:15px; float:left; color:green; ">';
	while($faq2=mysql_fetch_array($faq))
	{
		echo $faq2['title']."<br/>". $faq2['content']."<br/>"."<br/>";
	}

	echo "<br />";
	echo '</div>';

	
?>