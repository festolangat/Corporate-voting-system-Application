<span>
<?php
	$query1=mysql_connect("localhost","root","");
	mysql_select_db("onlinevoting",$query1);

	$query=mysql_query("select * from about");
	//print 10 items
	echo '<div style="font-size:15px; float:left; color:green; ">';
	while($query2=mysql_fetch_array($query))
	{
		echo $query2['title']."<br/>". $query2['content']."<br/>"."<br/>";
	}

	echo "<br />";
	echo '</div>';
	

	
?>
</span>