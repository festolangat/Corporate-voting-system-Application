<?php
	require_once('auth.php');
?>
<html>
<head>
<title>
	Professional results
</title>
<link rel="icon" type="image/png" href="../favicon.png" />
<!-- CSS Style -->
<link rel="stylesheet" href="admin/admin.css">
<!--sa poip up-->
<script src="argiepolicarpio.js" type="text/javascript" charset="utf-8"></script>
<script src="js/application.js" type="text/javascript" charset="utf-8"></script>
<link href="src/facebox.css" media="screen" rel="stylesheet" type="text/css" />
<script src="lib/jquery.js" type="text/javascript"></script>
<script src="src/facebox.js" type="text/javascript"></script>
<script type="text/javascript">
  jQuery(document).ready(function($) {
    $('a[rel*=facebox]').facebox({
      loadingImage : 'src/loading.gif',
      closeImage   : 'src/closelabel.png'
    })
  })
</script>
<script language="javascript">
function Clickheretoprint()
{ 
  var disp_setting="toolbar=yes,location=no,directories=yes,menubar=yes,"; 
      disp_setting+="scrollbars=yes,width=700, height=400, left=100, top=25"; 
  var content_vlue = document.getElementById("content").innerHTML; 
  
  var docprint=window.open("","",disp_setting); 
   docprint.document.open(); 
   docprint.document.write('</head><body onLoad="self.print()" style="width: 700px; font-size:11px; font-family:arial; font-weight:normal;">');          
   docprint.document.write(content_vlue); 
   docprint.document.close(); 
   docprint.focus(); 
}
</script>
</head>
<body>
	
	<div class="container  clearfix">
				
		<div class="two-thirds1 column">
			<div class="thewraper">
			<div style="margin-top: 8px;">
			<a id="addd" href="javascript:Clickheretoprint()">Print</a> &nbsp;  &nbsp; &nbsp; &nbsp;<span style="text-align: center; font:80px; display: inline-block;">Professional results Analysis</span>
				&nbsp;  &nbsp; &nbsp; &nbsp; <span style="font-size:10px; text-decoration:none;"><a href="close.php">Logout</a></span>
			</div>
				<div class="content" id="content">
				
				<?php
				include('connect.php');
				$query1 = $db->prepare("SELECT * FROM position ORDER BY id ASC");
					$query1->bindParam(':userid', $res);
					$query1->execute();
					for($i=0; $row = $query1->fetch(); $i++){
					$getname=$row['name'];
					
					$query2 = $db->prepare("SELECT sum(votes) FROM candidates WHERE position= :a");
					$query2->bindParam(':a', $getname);
					$query2->execute();
					for($i=0; $rowa = $query2->fetch(); $i++){
					$sumvotes=$rowa['sum(votes)'];
					}
					echo '<div style="margin-top: 30px;">';
					
					echo '<strong> <br /> '.$row['name'].'&nbsp;&nbsp;Total Votes casted for this Position:&nbsp;&nbsp;'.$sumvotes.'</strong><br><br>';
					
					$query3 = $db->prepare("SELECT * FROM candidates WHERE position= :a ORDER BY votes DESC");
					$query3->bindParam(':a', $getname);
					$query3->execute();
					for($i=0; $rows = $query3->fetch(); $i++){
						
						$totalvote=$sumvotes
						?>
						
						<img src="admin/candidates/<?php echo $rows['image']; ?>" width="70" height="70" style="margin-bottom: -26px;" /> &nbsp; &nbsp;<?php echo $rows['name']; ?> &nbsp;&nbsp;&nbsp;
		
						<img src="admin/pollyes.gif"
						
						width='<?php echo(100*round($rows['votes']/($totalvote),2)); ?>'
						height='10'>
						<?php echo(100*round($rows['votes']/($totalvote),2)); ?>%<br><br><br><br>
						<?php
						
						
						
					}
					echo '</div>';
					
					
					
				}
				?>
				</div>
			</div>
		</div>
	</div>
	
</body>
</html>