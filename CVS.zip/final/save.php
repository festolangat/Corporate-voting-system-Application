
<?php
//Start session
session_start();

//Array to store validation errors
$errmsg_arr = array();

//Validation error flag
$flagerror = false;

//Connect to mysql server
include('connect.php');


$c=$_POST['username'];
$d=$_POST['password'];
$w=$_POST['rpassword'];
$x=$_POST['question'];
$y=$_POST['ans'];
$e='notuse';
$f='notvoted';
$g='used';
if ($w!=$d) {
$errmsg_arr[] = 'password mismatch';
$flagerror = true;
}
if($flagerror) {
	$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
	session_write_close();
	header("location: index.php");
	exit();
}
$query1 = $db->prepare("SELECT * FROM list_stu_num WHERE id_number= :k AND status= :l");
$query1->bindParam(':k', $c);
$query1->bindParam(':l', $e);
$query1->execute();
for($i=0; $row1 = $query1->fetch(); $i++){
	$a=$row1['name'];
    $b=$row1['profession'];
	}

$query2 = $db->prepare("SELECT * FROM list_stu_num WHERE id_number= :a AND status= :e");
$query2->bindParam(':a', $c);
$query2->bindParam(':e', $e);
$query2->execute();
$rows = $query2->fetch(PDO::FETCH_NUM);
if($rows > 0) {
	
	$sql = "INSERT INTO voters (name,profession,username,password,status,question,answer) VALUES (:a,:b,:c,:d,:f,:x,:y)";
	$q = $db->prepare($sql);
	$q->execute(array(':a'=>$a,':b'=>$b,':c'=>$c,':d'=>$d,':f'=>$f,':x'=>$x,':y'=>$y));
	
	$sqla = "UPDATE list_stu_num 
        SET status=?
		WHERE id_number=?";
$qa = $db->prepare($sqla);
$qa->execute(array($g,$c));
$errmsg_arr[] = 'Registered Successful!. You can now login to Continue';
$flagerror = true;
header("location: index.php?#Registered#Successful!#You#can#now#login#to#Continue");
}
else{
	$errmsg_arr[] = 'Invalid Staff ID or ID has Expired!.Contact Administrator for Assistant';
	$flagerror = true;
	session_write_close();
	header("location: index.php?#Invalid#deatils#contactAdministrator&for#assistance");
	exit();
}
if($flagerror) {
	$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
	session_write_close();
	header("location: index.php?#Registered#Successful!#Proceed#to#login#using#username#'$c'");
	exit();
}
?>
 <script type="text/javascript">window.onload = date_time('date_time');</script>