<!DOCTYPE html>
 <html class="no-js"> 
						
	
<head>
    <meta charset="utf-8">
    
    <title>CVS system</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width">   
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800" rel="stylesheet">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/normalize.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/templatemo_misc.css">
    <link rel="stylesheet" href="css/templatemo_style.css">
    <script src="js/vendor/modernizr-2.6.2.min.js"></script>
	<!---Time script---->
	 <script type="text/javascript" src="date_time.js"></script>
	<!----Login---->
	<link rel="icon" type="image/png" href="favicon.png" />
	<link href="style.css" media="screen" rel="stylesheet" type="text/css" />
	<!--sa poip up-->
	<link href="admin/src/facebox.css" media="screen" rel="stylesheet" type="text/css" />
	<script src="admin/lib/jquery.js" type="text/javascript"></script>
	<script src="admin/src/facebox.js" type="text/javascript"></script>
	<script type="text/javascript">
  jQuery(document).ready(function($) {
    $('a[rel*=facebox]').facebox({
      loadingImage : 'loading.gif',
      closeImage   : 'admin/src/closelabel.png'
    })
  })
</script>
</head>
<body>
    
    
    <div class="bg-overlay"></div>

    <div class="container-fluid">
        <div class="row">
            
            <div class="col-md-4 col-sm-12">
                <div class="sidebar-menu">
                    
                    <div class="logo-wrapper">
                        <h1 class="logo">
							
							 <span id="date_time"></span>
							 <script type="text/javascript">window.onload = date_time('date_time');</script>
                            <a href="#"><img src="images/logo.png" alt="Circle Template">
                            <span>Corporate Voting system Application</span></a>
                        </h1>
                    </div> <!-- /.logo-wrapper -->
                    
                    <div class="menu-wrapper">
                        <ul class="menu">
                            <li><a class="homebutton"href="#" title="This is Welcoming page">Home</a></li>
                            <li><a class="show-1" href="#" title="Learn about the application">About</a></li>
                           	<li><a class="show-2" href="#" title="Login to cast the vote">Login</a></li>  
							<li><a class="show-3" href="#" title="create users account for the first time user in order to login ">Register</a></li> 
							<li><a class="show-4" href="#" title="Check professional_results">Results</a></li>
                        </ul> <!-- /.menu -->
                           
                        </ul> <!-- /.menu -->
                        <a href="#" class="toggle-menu"><i class="fa fa-bars"></i></a>
                    </div> <!-- /.menu-wrapper -->


                </div> <!-- /.sidebar-menu -->
            </div> <!-- /.col-md-4 -->

            <div class="col-md-8 col-sm-12">
                
                <div id="menu-container">

                    <div id="menu-1" class="about content">
                        <div class="row">
                            <ul class="tabs">
                                <li class="col-md-4 col-sm-4">
                                    <a href="#tab1" class="icon-item">
                                        <i class="fa fa-lemon-o"> About</i>
                                    </a> <!-- /.icon-item -->
                                </li>
							 
                                <li class="col-md-4 col-sm-4">
                                    <a href="#tab2" class="icon-item">
                                        <i class="fa fa-question"> FAQ</i>
                                    </a> <!-- /.icon-item -->
                                </li>
                                <li class="col-md-4 col-sm-4">
                                    <a href="#tab3" class="icon-item">
                                        <i class="fa fa-phone">Help</i>
                                    </a> <!-- /.icon-item -->
                                </li>
                            </ul> <!-- /.tabs -->
                            <div class="col-md-12 col-sm-12">
                                <div class="toggle-content text-left" id="tab1">
                                  <span>
								  <?php
										$query1=mysql_connect("localhost","root","");
										mysql_select_db("onlinevoting",$query1);

										$query=mysql_query("select * from about");
										//print 10 items
										echo '<div style="font-size:15px; float:left; color:green; ">';
										while($query2=mysql_fetch_array($query))
										{
											echo $query2['title']."<br/>". $query2['content']."<br/>"."<br/>";
										}

										echo "<br />";
										echo '</div>';
										

										
									?>
																	  
								</div>

                                <div class="toggle-content" id="tab2">
                                    <span>
								  <?php
										$query1=mysql_connect("localhost","root","");
										mysql_select_db("onlinevoting",$query1);

										$faq=mysql_query("select * from faq");
										//print 10 items
										echo '<div style="font-size:15px; float:left; color:green; ">';
										while($faq2=mysql_fetch_array($faq))
										{
											echo $faq2['title']."<br/>". $faq2['content']."<br/>"."<br/>";
										}

										echo "<br />";
										echo '</div>';

										
									?>
									
								</div>

                                <div class="toggle-content text-left" id="tab3">
                                    <h3>Our Team</h3>
                                    <p>Corporate voting system (OVS) will reduce the time to travel to polling station, time spent in long queue. It will enable voters to vote anywhere, anytime since the application will be available on the web. Case of incorrect tallying of votes will be solve because of right functionality implemented and strong database to store and retrieve data as requested. It will also reduce the voter’s coercion since voters will not converge in one place.</p>
								
								</div>
                            </div> <!-- /.col-md-12 -->
                        </div> <!-- /.row -->

                    </div> <!-- /.about -->
					
					<!-- /.start Login -->
                    <div id="menu-2" class="contact content">
                        <div class="row">
                        	
                            <div class="col-md-9">
                                <div class="contact-form">

                                    <div class="row">
										<?php date_default_timezone_set("Africa/Nairobi"); $date= date('H'); ?>
										
                                    	<form action="login.php" method="post">
											<fieldset class="col-md-9">
                                                <input id="name" type="text"  name="date_time" value="<?php echo $date;?>"style="display:none;"; required />
                                            </fieldset> 
                                            <fieldset class="col-md-9">
                                                <input id="name" type="text" name="username" placeholder="Username" required>
                                            </fieldset>                                            
                                            <fieldset class="col-md-9">
                                                <input type="password" name="password" id="subject" placeholder="Password" required>
                                            </fieldset>    
											<fieldset class="col-md-9">
                                             <select name="asas" style="display:none;"> 												
												<option>voter</option>												
											</select>   
                                            </fieldset>
											
                                            <fieldset class="col-md-9">
                                                <input type="submit" value="Login" id="btn" class="button">
                                            </fieldset>
											<fieldset class="col-md-9">											
                                               <a href="pwordrecover.php" style="color:green; height:100%;width: 100%;"><em> Forgot password?</em></a >
                                            </fieldset>
                                        </form>
                                    </div> <!-- /.row -->
                                </div> <!-- /.contact-form -->
                            </div> <!-- /.col-md-12 -->
                        </div> <!-- /.row -->
                    </div> <!-- /.End Login -->

					<!---Start of results--->
                    <!-- /.start Login -->
                    <div id="menu-4" class="contact content">
                        <div class="row">
                            
                            <div class="col-md-9">
                                <div class="contact-form">

                                    <div class="row">
                                        
                                        <form action="checkval.php" method="post">
                                            
                                            <fieldset class="col-md-9">
                                                <input id="name" type="text" name="username" placeholder="Username" required>
                                            </fieldset>                                            
                                            <fieldset class="col-md-9">
                                                <input type="password" name="password" id="subject" placeholder="Password" required>
                                            </fieldset>    
                                            <fieldset class="col-md-9">
                                             <select name="asas" style="display:none;">                                                 
                                                <option>voter</option>                                              
                                            </select>   
                                            </fieldset>
                                            
                                            <fieldset class="col-md-9">
                                                <input type="submit" value="Login" id="btn" class="button">
                                            </fieldset>
                                            <fieldset class="col-md-9">                                         
                                               <a href="pwordrecover.php" style="color:green; height:100%;width: 100%;"><em> Forgot password?</em></a >
                                            </fieldset>
                                        </form>
                                    </div> <!-- /.row -->
                                </div> <!-- /.contact-form -->
                            </div> <!-- /.col-md-12 -->
                        </div> <!-- /.row -->
                    </div> <!-- /.End Login -->

                    <!---End of results check--->
										
					<!-- /.start register -->
					<div id="menu-3" class="contact content">
                        <div class="row">
                        	
                            <div class="col-md-9">
                                <div class="contact-form">
                                    <div class="row">
                                    	<form NAME = "frmOne" style="z-index:999;" action="save.php" method="POST" onsubmit="return validateForm()">
                                            <fieldset class="col-md-9">
                                                <input id="name" type="text" name="username" placeholder="Reference code" required >
                                            </fieldset>                                            
                                            <fieldset class="col-md-9">
                                                <input type="password" name="password" id="subject" placeholder="Password" required >
                                            </fieldset>  
											<fieldset class="col-md-9">
                                            <input type="password" name="rpassword" id="subject" placeholder="Confirm password" required >
                                            </fieldset><br/><br/><br/>
											
											<fieldset class="col-md-9">											
											<select name="question" required>
											<option>Select Security Question</option>
											<option>what is your favorite color</option>
											<option>what is your favorite movie</option>
											<option>what is your favorite singer</option>
											<option>what is your favorite pet</option>
											<option>what is your favorite cartoon character</option>
											</select>
                                            </fieldset>											
											
											<fieldset class="col-md-9">											
                                               <input type="text" name="ans" value="" placeholder="Answer" required >
                                            </fieldset>											
                                            <fieldset class="col-md-9">											
                                                <input type="submit" name="submit" value="submit" class="button">
                                            </fieldset>
											
                                        </form>
                                    </div> <!-- /.row -->
                                </div> <!-- /.contact-form -->
                            </div> <!-- /.col-md-12 -->
                        </div> <!-- /.row -->
                    </div> <!-- /.end of register -->
				
                </div> <!-- /#menu-container -->

            </div> <!-- /.col-md-8 -->

        </div> <!-- /.row -->
    </div> <!-- /.container-fluid -->
    
    <div class="container-fluid">   
        <div class="row">
            <div class="col-md-12 footer">
                <p id="footer-text">
                <a href="#">&copy; 2016 Project CVS design and coded by Langat Festus  </a> 
                                   
                 </p>
            </div><!-- /.footer --> 
        </div>
    </div> <!-- /.container-fluid -->

    <script src="js/vendor/jquery-1.10.1.min.js"></script>
    <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.10.1.min.js"><\/script>')</script>
    <script src="js/jquery.easing-1.3.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>
    <script type="text/javascript">
            
			jQuery(function ($) {

                $.supersized({

                    // Functionality
                    slide_interval: 3000, // Length between transitions
                    transition: 1, // 0-None, 1-Fade, 2-Slide Top, 3-Slide Right, 4-Slide Bottom, 5-Slide Left, 6-Carousel Right, 7-Carousel Left
                    transition_speed: 700, // Speed of transition

                    // Components                           
                    slide_links: 'blank', // Individual links for each slide (Options: false, 'num', 'name', 'blank')
                    slides: [ // Slideshow Images
                        {
                            image: 'images/templatemo-slide-1.jpg'
                        }, {
                            image: 'images/templatemo-slide-2.jpg'
                        }, {
                            image: 'images/templatemo-slide-3.jpg'
                        }, {
                            image: 'images/templatemo-slide-4.jpg'
                        }
                    ]

                });
            });
            
    </script>
	
	<!----register validation---->
	
	<script type="text/javascript">
		function validateForm()
		{
		var a=document.forms["frmOne"]["password"].value;
		var b=document.forms["frmOne"]["rpassword"].value;
		if (a!=b)
		  {
		  alert("password mismatch");
		  return false;
		  }
		}
	</script>
	
	<!-----End of register script-------------->
    
    	<!-- Google Map -->
        <script src="http://maps.google.com/maps/api/js?sensor=true"></script>
        <script src="js/vendor/jquery.gmap3.min.js"></script>
        <!-- Google Map Init-->
        <script type="text/javascript">
           function templatemo_map() {
                $('.google-map').gmap3({
                    marker:{
                        address: '16.8496189,96.1288854' 
                    },
                        map:{
                        options:{
                        zoom: 15,
                        scrollwheel: false,
                        streetViewControl : true
                        }
                    }
                });
            }
        </script>
</body>
</html>